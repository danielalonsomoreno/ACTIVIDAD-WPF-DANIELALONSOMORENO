﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_WPF.DTO
{
    internal class coches
    {
        public String Nombre { get; set; }
        //POnemos la marca en privado
        private String marca;
        //accederemos de forma privada al get y al set.
        public string Marca
        {
            get { return marca;}
            
        
        set 
        {
            marca = value;
        }
    }
        //El constructor recibira 2 valores
        public coches(string nombre, string marca)
        {
            Nombre = nombre;
            Marca = marca;
        }
        public override string ToString()
        {
            return Nombre +" "+ marca;
        }
    }
}
