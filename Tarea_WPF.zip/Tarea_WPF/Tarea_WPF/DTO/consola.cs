﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_WPF.DTO
{
    public class consola
    {
        public String Nombre { get; set; }
        //POnemos la marca en privado
        public String marca { get; set; }
        //accederemos de forma privada al get y al set.
        public string Marca
        {
            get { return marca; }


            set
            {
                marca = value;
            }
        }
        //El constructor recibira 2 valores
        public consola(string nombre, string marca)
        {
            Nombre = nombre;
            Marca = marca;
        }
        //Segundo constructor
        public consola()
        {
            Nombre = "Switch";
            Marca = "Nintendo";
        }
        public override string ToString()
        {
            return Nombre + " " + marca;
        }
    }
}

