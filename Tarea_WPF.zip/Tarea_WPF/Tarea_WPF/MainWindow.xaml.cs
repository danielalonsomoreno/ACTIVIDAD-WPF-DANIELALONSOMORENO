﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Tarea_WPF.DTO;

namespace Tarea_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Definiremos la lista personas
        public ObservableCollection<consola> listaConsolas { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            //Aqui inicializaremos la lista de personas
            List<coches> listaCoches = new List<coches>();
            listaCoches.Add(new coches("Aston", "Martin"));
            listaCoches.Add(new coches("El coche","Cito"));
            //Iremos metiendo los coches en la lista coches
            foreach (coches coche in listaCoches)
            {
                ComboBoxItem cbi = new ComboBoxItem();
                cbi.Content = coche;
                ComboboxCoches.Items.Add(cbi);
            }
            listaConsolas = new ObservableCollection<consola>();
            listaConsolas.Add(new consola());
            
            listaConsolas.Add(new consola("Playstation", "sony"));
            //Para hacer bien el binding
            this.DataContext= this;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Hola_label.Visibility = System.Windows.Visibility.Hidden;
        }

        private void ComboboxCoches_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem cbi = (ComboBoxItem)ComboboxCoches.SelectedItem;
            coches coche = (coches)cbi.Content;
            LabelNombre.Content = coche.Nombre;
            LabelMarca.Content= coche.Marca;
        }

        private void Observar_Click(object sender, RoutedEventArgs e)
        {
            listaConsolas.Add(new consola("los", "nintendos"));
        }
    }
}
